/* xlsx.js (C) 2013-present  SheetJS -- http://sheetjs.com */
define(['xlsx'], function (_XLSX) {
	/* work around require.js */
	return XLSX;
});
