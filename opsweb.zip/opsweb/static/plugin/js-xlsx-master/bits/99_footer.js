})(typeof exports !== 'undefined' ? exports : XLSX);
/*exported XLS, ODS */
var XLS = XLSX, ODS = XLSX;
